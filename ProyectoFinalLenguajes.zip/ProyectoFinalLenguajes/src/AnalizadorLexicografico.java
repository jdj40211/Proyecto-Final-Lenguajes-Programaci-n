public class AnalizadorLexicografico {
    private String[] palabras;

    public AnalizadorLexicografico(String[] palabras) {
        this.palabras = palabras;
    }

    public String[] getPalabras() {
        return palabras;
    }

    // Función para obtener el número de palabras en la cadena de texto
    public int getNumeroDePalabras() {
        return this.palabras.length;
    }
    // Función para obtener el número de caracteres en la cadena de texto
    public int getNumeroDeCaracteres() {
        int numeroDeCaracteres = 0;
        for (String palabra : this.palabras) {
            numeroDeCaracteres += palabra.length();
        }
        return numeroDeCaracteres;
    }

}
