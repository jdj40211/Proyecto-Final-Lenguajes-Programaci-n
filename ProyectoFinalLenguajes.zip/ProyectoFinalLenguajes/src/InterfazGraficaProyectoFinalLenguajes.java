import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.net.URL;

public class InterfazGraficaProyectoFinalLenguajes extends JPanel {
    private JLabel tituloIngreseTexto;
    private static JTextArea entradaDeTexto;
    private static JButton botonProcesarTexto;
    private static JTextField cajaDescripcionTexto;
    private JLabel jcomp7;
    private static JTextPane salidaDeTexto;

    private static final Map<String, String> emoticonesMapa = new HashMap<>();
    static {
        emoticonesMapa.put(":)", "014-sonrisa.JPG");
        emoticonesMapa.put(":(", "009-triste.JPG");
        emoticonesMapa.put(":D", "005-sonriente.JPG");
        emoticonesMapa.put(";)", "018-guino.JPG");
        emoticonesMapa.put(":p", "023-cabeza-alienigena-1.JPG");
        emoticonesMapa.put("xD", "058-riendo.JPG");
        emoticonesMapa.put(":-)", "003-feliz.JPG");
        emoticonesMapa.put(":-(", "059-triste-2.JPG");
        emoticonesMapa.put("(y)", "031-me-gusta-1.JPG");
        emoticonesMapa.put("(n)", "028-pulgares-abajo.JPG");
        emoticonesMapa.put("<3", "067-corazon.JPG");
        emoticonesMapa.put(":o", "004-conmocionado.JPG");
        emoticonesMapa.put(":|", "008-confuso.JPG");
        emoticonesMapa.put(":*", "001-emoji.JPG");
        emoticonesMapa.put(">:(", "011-enojado.JPG");
        emoticonesMapa.put(":-]", "019-entusiasta.JPG");
    }

    public InterfazGraficaProyectoFinalLenguajes() {
        setLayout(null);

        // Crear componentes
        tituloIngreseTexto = new JLabel("Ingrese un texto:");
        entradaDeTexto = new JTextArea(5, 5);
        jcomp7 = new JLabel("PROYECTO FINAL LENGUAJES DE PROGRAMACIÓN");
        salidaDeTexto = new JTextPane();


        // Configurar el JTextPane para que muestre imágenes
        salidaDeTexto.setContentType("text/html");
        salidaDeTexto.setEditable(false);

        // Configurar el JTextArea para que muestre un borde
        setPreferredSize(new Dimension(754, 427));

        // Añadir componentes al panel
        add(tituloIngreseTexto);
        add(entradaDeTexto);
        add(jcomp7);
        add(salidaDeTexto);

        // Ajustar los componentes al panel
        tituloIngreseTexto.setBounds(61, 65, 107, 45);
        entradaDeTexto.setBounds(175, 70, 350, 35);
        jcomp7.setBounds(205, 5, 345, 30);
        salidaDeTexto.setBounds(115, 170, 415, 65);
        botonProcesarTexto = new JButton("Procesar Cadena de texto");
        cajaDescripcionTexto = new JTextField(6);

        add(botonProcesarTexto);
        add(cajaDescripcionTexto);

        botonProcesarTexto.setBounds(255, 120, 195, 25);
        cajaDescripcionTexto.setBounds(190, 285, 330, 45);

        // Añadir componentes al panelImagenes
        mostrarImagenes();

        botonProcesarTexto.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Acción al hacer clic en el botón
                procesarTexto();
            }
        });
    }



    private void mostrarImagenes() {
        for (Map.Entry<String, String> entry : emoticonesMapa.entrySet()) {
            String rutaImagen = "/emojicshd/png/" + entry.getValue();
            URL url = getClass().getResource(rutaImagen);
            if (url != null) {
                System.out.println("URL de la imagen: " + url.toExternalForm());



            } else {
                System.err.println("No se pudo obtener la URL de la imagen: " + rutaImagen);
            }
        }
    }

    private String reemplazarEmoticones(String texto) {
        for (Map.Entry<String, String> entry : emoticonesMapa.entrySet()) {
            String emoticon = entry.getKey();
            String imagen = entry.getValue();
            String rutaImagen = "emojicshd/png/" + imagen;
            texto = texto.replace(emoticon, "<img src='" + getClass().getResource(rutaImagen) + "'/>");
        }

        return texto;
    }

    private void procesarTexto() {
        String textoEntrada = entradaDeTexto.getText();
        String textoModificado = reemplazarEmoticones(textoEntrada);

        int[] conteoPalabrasYEmoticones = contarPalabrasYEmoticones(textoModificado);

        cajaDescripcionTexto.setText("Número de palabras: " + conteoPalabrasYEmoticones[0] +
                " | Número de emoticones: " + conteoPalabrasYEmoticones[1]);

        String frase = textoModificado;

        salidaDeTexto.setText(frase);


        mostrarImagenes();

    }

    // Contador de palabras por medio de un arreglo
    private static int[] contarPalabrasYEmoticones(String texto) {
        int[] conteoPalabrasYEmoticones = new int[2];

        for (Map.Entry<String, String> entry : emoticonesMapa.entrySet()) {
            String emoji = entry.getKey();
            String direccionImagen = entry.getValue();

            // Reemplaza cada emoji por la dirección de la imagen y cuenta los emoticones
            texto = texto.replace(emoji, direccionImagen);
            conteoPalabrasYEmoticones[1] += contarOcurrencias(texto, direccionImagen);
        }

        // Divide la cadena por espacios y cuenta las palabras
        String[] palabras = texto.replaceAll("\\s+", "").split(" ");
        conteoPalabrasYEmoticones[0] = palabras.length;

        return conteoPalabrasYEmoticones;
    }



    // Método para contar el número de ocurrencias de una subcadena en una cadena
    private static int contarOcurrencias(String texto, String subcadena) {
        int conteo = 0;
        int indice = texto.indexOf(subcadena);
        while (indice != -1) {
            conteo++;
            indice = texto.indexOf(subcadena, indice + 1);
        }
        return conteo;
    }



    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("InterfazGraficaProyectoFinalLenguajes");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            InterfazGraficaProyectoFinalLenguajes panel = new InterfazGraficaProyectoFinalLenguajes();
            frame.getContentPane().add(panel);
            frame.pack();
            frame.setVisible(true);
        });
    }
}
